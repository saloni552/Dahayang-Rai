type HeroImageProps = {
  src: string;
  alt?: string;
  caption?: string;
  className?: string;
  rotate?: number; // degrees to rotate the polaroid
};

export default function HeroImage({
  src,
  alt = "",
  caption,
  className = "",
  rotate = -6
}: HeroImageProps) {
  return (
    <div className={`flex items-start justify-center ${className} relative z-10`}>
      {/* outer rotated container (doesn't include hover translate) */}
      <div style={{ transform: `rotate(${rotate}deg)` }} className="inline-block">
        <div className="relative transform transition-transform duration-300 hover:-translate-y-2">
          {/* polaroid white frame */}
          <div className="bg-white rounded-md shadow-2xl p-3 md:p-4 w-full">
              <div className="bg-slate-100 rounded-sm overflow-hidden w-[300px] h-[380px] md:w-[420px] md:h-[520px]">
              <img
                src={src}
                alt={alt}
                className="w-full h-full object-cover block"
                loading="lazy"
                decoding="async"
              />
            </div>

            {/* caption area like a polaroid foot */}
            <div className="mt-3 text-center">
              <p className="text-sm font-medium text-[#4A4A4A]">{caption}</p>
            </div>
          </div>

          {/* subtle drop shadow is handled by the card's box-shadow (avoid absolute overlays that create stacking issues) */}
        </div>
      </div>
    </div>
  );
}
